package com.cinerec.mixin;

import com.cinerec.GreenScreenFilter;
import net.minecraft.client.renderer.culling.Frustum;
import net.minecraft.client.renderer.entity.EntityRenderDispatcher;
import net.minecraft.world.entity.Entity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(EntityRenderDispatcher.class)
public class EntityRenderDispatcherMixin {
    // require = 0: لو اسم/توقيع الدالة تغيّر في 26.2 ما يكرّش اللعبة، بس الفلتر ما يشتغل.
    // تأكد بأمر: /cinerec green status  (لازم hookCalls يزيد)
    @Inject(method = "shouldRender", at = @At("HEAD"), cancellable = true, require = 0)
    private void cinerec$greenScreenFilter(Entity entity, Frustum frustum, double x, double y, double z,
                                           CallbackInfoReturnable<Boolean> cir) {
        GreenScreenFilter.hookCalls++;
        if (GreenScreenFilter.shouldHide(entity)) {
            cir.setReturnValue(false);
        }
    }
}
