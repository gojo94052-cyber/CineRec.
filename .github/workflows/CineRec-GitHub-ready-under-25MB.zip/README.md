# CineRec

Fabric mod project for Minecraft 26.2.

Target:
- Fabric Loader 0.19.5
- Java 25
- Gradle 9.8.0

GitHub Actions builds the mod automatically.

After a successful build, download the JAR from:
Actions -> Build CineRec Mod -> Artifacts
