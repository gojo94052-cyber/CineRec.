package com.cinerec;

import com.mojang.blaze3d.platform.Screenshot;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.Minecraft;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.RejectedExecutionException;
import java.util.concurrent.Semaphore;

/** يلتقط لقطات العالم (بدون GUI) ويحفظها PNG في .minecraft/cinerec/<وقت>/ */
public final class FrameRecorder {
    private static final Logger LOG = LoggerFactory.getLogger("cinerec");
    private static final int MAX_QUEUED = 4;

    private volatile boolean recording;
    private Path dir;
    private ExecutorService writer;
    private final Semaphore slots = new Semaphore(MAX_QUEUED);
    private long nextFrameNanos;
    private volatile int frameCount;

    public boolean isRecording() { return recording; }
    public int frames() { return frameCount; }

    public synchronized Path start() throws IOException {
        if (recording) return dir;
        String stamp = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss"));
        dir = FabricLoader.getInstance().getGameDir().resolve("cinerec").resolve(stamp);
        Files.createDirectories(dir);
        writer = Executors.newSingleThreadExecutor(r -> new Thread(r, "cinerec-writer"));
        frameCount = 0;
        nextFrameNanos = 0;
        recording = true;
        return dir;
    }

    public synchronized int stop() {
        recording = false;
        if (writer != null) writer.shutdown();
        return frameCount;
    }

    /** يُستدعى من LevelRendererMixin بعد رسم العالم وقبل الواجهة. */
    public void onFrame() {
        if (!recording) return;
        long now = System.nanoTime();
        if (now < nextFrameNanos) return;
        nextFrameNanos = now + 1_000_000_000L / Math.max(1, CineRecConfig.get().fps);
        if (!slots.tryAcquire()) return;

        final ExecutorService out = writer;
        final Path file = dir.resolve(String.format("frame_%06d.png", ++frameCount));

        // TODO تحقق من التوقيع في 26.2
        Screenshot.takeScreenshot(Minecraft.getInstance().gameRenderer.mainRenderTarget(), image -> {
            try {
                out.execute(() -> {
                    try {
                        image.writeToFile(file);
                    } catch (IOException e) {
                        LOG.error("Failed to write {}", file, e);
                    } finally {
                        image.close();
                        slots.release();
                    }
                });
            } catch (RejectedExecutionException e) {
                image.close();
                slots.release();
            }
        });
    }
}
