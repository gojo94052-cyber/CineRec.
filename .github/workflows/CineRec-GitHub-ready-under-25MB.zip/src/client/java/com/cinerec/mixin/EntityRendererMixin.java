package com.cinerec.mixin;

import com.cinerec.CineRecConfig;
import com.cinerec.GreenScreenFilter;
import net.minecraft.client.renderer.entity.EntityRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(EntityRenderer.class)
public class EntityRendererMixin {
    // 26.2: extractNameplates صارت extractNameTags
    @Inject(method = "extractNameTags", at = @At("HEAD"), cancellable = true, require = 0)
    private void cinerec$hideNames(CallbackInfo ci) {
        GreenScreenFilter.nameHookCalls++;
        if (CineRecConfig.get().hideNames) ci.cancel();
    }
}
