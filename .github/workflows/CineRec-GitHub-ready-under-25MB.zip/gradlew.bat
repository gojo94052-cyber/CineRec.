@echo off
rem Gradle wrapper launcher (Windows). Downloads gradle-wrapper.jar on first run.
set "APP_HOME=%~dp0"
set "JAR=%APP_HOME%gradle\wrapper\gradle-wrapper.jar"

if not exist "%JAR%" (
  echo gradle-wrapper.jar missing, downloading...
  if not exist "%APP_HOME%gradle\wrapper" mkdir "%APP_HOME%gradle\wrapper"
  powershell -NoProfile -Command "$ProgressPreference='SilentlyContinue'; try { Invoke-WebRequest -UseBasicParsing 'https://raw.githubusercontent.com/gradle/gradle/v9.5.1/gradle/wrapper/gradle-wrapper.jar' -OutFile '%JAR%' } catch { Invoke-WebRequest -UseBasicParsing 'https://raw.githubusercontent.com/gradle/gradle/master/gradle/wrapper/gradle-wrapper.jar' -OutFile '%JAR%' }"
)
if not exist "%JAR%" (
  echo Download failed. Check your internet.
  exit /b 1
)

if defined JAVA_HOME ( set "JAVACMD=%JAVA_HOME%\bin\java.exe" ) else ( set "JAVACMD=java" )
"%JAVACMD%" -Dorg.gradle.appname=gradlew -jar "%JAR%" %*
