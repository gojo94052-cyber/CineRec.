package com.cinerec.mixin;

import com.cinerec.CineRecClient;
import net.minecraft.client.renderer.LevelRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(LevelRenderer.class)
public class LevelRendererMixin {
    // 26.2: renderLevel صارت render. نلتقط بعد رسم العالم وقبل الواجهة.
    @Inject(method = "render", at = @At("TAIL"), require = 0)
    private void cinerec$capture(CallbackInfo ci) {
        CineRecClient.RECORDER.onFrame();
    }
}
