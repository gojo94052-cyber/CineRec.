package com.cinerec.mixin;

import com.cinerec.Hotkey;
import net.minecraft.client.Minecraft;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(Minecraft.class)
public class MinecraftMixin {
    @Inject(method = "runTick", at = @At("HEAD"), require = 0)
    private void cinerec$pollHotkey(boolean advanceGameTime, CallbackInfo ci) {
        Hotkey.poll((Minecraft) (Object) this);
    }
}
