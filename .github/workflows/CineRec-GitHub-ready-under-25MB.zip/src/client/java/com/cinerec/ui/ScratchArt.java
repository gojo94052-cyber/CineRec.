package com.cinerec.ui;

import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphicsExtractor;

/** صور تعليمية بأسلوب سكراتش (بلوكات ملونة) مرسومة بالكود، بدون أي ملفات صور. */
final class ScratchArt {
    static final int EVENT = 0xFFFFBF00, LOOKS = 0xFF9966FF, SENSE = 0xFF5CB1D6,
                     SOUND = 0xFFCF63CF, CONTROL = 0xFFFFAB19, MOTION = 0xFF4C97FF;

    private record Block(int color, String text, boolean hat) {}

    private ScratchArt() {}

    private static Block[] blocks(String id) {
        return switch (id) {
            case "hideNames" -> new Block[]{
                new Block(EVENT, "when REC", true),
                new Block(LOOKS, "hide names", false),
                new Block(CONTROL, "keep world", false)};
            case "greenScreen" -> new Block[]{
                new Block(EVENT, "when REC", true),
                new Block(LOOKS, "hide others", false),
                new Block(LOOKS, "bg = green", false)};
            case "fps" -> new Block[]{
                new Block(CONTROL, "forever", true),
                new Block(SENSE, "grab frame", false),
                new Block(CONTROL, "wait 1/fps", false)};
            case "audio" -> new Block[]{
                new Block(EVENT, "when REC", true),
                new Block(SOUND, "record mic", false),
                new Block(MOTION, "put on A1", false)};
            default -> new Block[]{ // trim
                new Block(EVENT, "click timeline", true),
                new Block(MOTION, "move playhead", false),
                new Block(CONTROL, "set In / Out", false)};
        };
    }

    private static String caption(String id) {
        return switch (id) {
            case "hideNames" -> "Name tags vanish in the video";
            case "greenScreen" -> "Only your target stays";
            case "fps" -> "Lower FPS = lighter on phone";
            case "audio" -> "Mic goes on track A1";
            default -> "Cut the clip at the playhead";
        };
    }

    static int height(String id) { return 22 + blocks(id).length * 18 + 14; }

    static void draw(GuiGraphicsExtractor g, Font font, String id, int x, int y, int w) {
        Block[] bs = blocks(id);
        int h = height(id);
        g.fill(x, y, x + w, y + h, 0xFFF3F6FB);
        g.fill(x, y, x + w, y + 12, 0xFFDCE4F2);
        g.text(font, "How it works", x + 4, y + 2, 0xFF4C5A73);

        boolean wide = w >= 200;
        int bw = wide ? w - 64 : w - 14;
        int bx = x + 6, by = y + 20;
        for (Block b : bs) {
            if (b.hat) g.fill(bx, by - 4, bx + bw * 6 / 10, by, b.color);
            g.fill(bx, by, bx + bw, by + 16, b.color);
            g.fill(bx, by + 15, bx + bw, by + 16, darker(b.color));
            g.fill(bx + 8, by + 16, bx + 22, by + 18, b.color); // notch
            g.text(font, b.text, bx + 4, by + 4, 0xFFFFFFFF);
            by += 18;
        }
        if (wide) stage(g, id, x + w - 52, y + 20);
        g.text(font, caption(id), x + 4, y + h - 11, 0xFF4C5A73);
    }

    /** مسرح صغير مثل سكراتش يوضح النتيجة. */
    private static void stage(GuiGraphicsExtractor g, String id, int sx, int sy) {
        boolean green = id.equals("greenScreen");
        g.fill(sx, sy, sx + 44, sy + 40, green ? 0xFF00B140 : 0xFF8FC1FF);
        g.fill(sx + 17, sy + 16, sx + 27, sy + 26, 0xFFE0B080);   // راس
        g.fill(sx + 15, sy + 26, sx + 29, sy + 38, 0xFF3D7CC9);   // جسم
        if (id.equals("hideNames")) {
            g.fill(sx + 10, sy + 6, sx + 34, sy + 12, 0xFF444444); // اسم اللاعب
            g.fill(sx + 8, sy + 8, sx + 36, sy + 10, 0xFFE5484D);  // شطب
        }
    }

    private static int darker(int c) {
        int r = ((c >> 16) & 255) * 7 / 10, gg = ((c >> 8) & 255) * 7 / 10, b = (c & 255) * 7 / 10;
        return 0xFF000000 | r << 16 | gg << 8 | b;
    }
}
