package com.cinerec;

import net.minecraft.client.Minecraft;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;

/** يقرر أي كيانات تنخفي لما الجرين سكرين شغال (يخلي الهدف فقط). */
public final class GreenScreenFilter {
    /** عدّاد يبيّن إن الـ Mixin فعلاً يشتغل (يظهر في /cinerec green status). */
    public static volatile long hookCalls = 0;
    public static volatile long nameHookCalls = 0;
    public static volatile long hiddenCount = 0;

    private GreenScreenFilter() {}

    public static boolean shouldHide(Entity entity) {
        CineRecConfig cfg = CineRecConfig.get();
        if (!cfg.greenScreen) return false;
        boolean keep = isTarget(entity, cfg);
        if (!keep) hiddenCount++;
        return !keep;
    }

    private static boolean isTarget(Entity e, CineRecConfig cfg) {
        switch (cfg.targetMode) {
            case "player":
                return e instanceof Player p
                    && p.getName().getString().equalsIgnoreCase(cfg.targetValue);
            case "mob":
                String id = BuiltInRegistries.ENTITY_TYPE.getKey(e.getType()).toString();
                return id.equalsIgnoreCase(cfg.targetValue)
                    || id.equalsIgnoreCase("minecraft:" + cfg.targetValue);
            case "self":
            default:
                return e == Minecraft.getInstance().player;
        }
    }
}
