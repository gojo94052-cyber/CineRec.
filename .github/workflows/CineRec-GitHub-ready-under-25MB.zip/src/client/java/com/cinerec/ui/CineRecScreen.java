package com.cinerec.ui;

import com.cinerec.CineRecClient;
import com.cinerec.CineRecConfig;
import com.cinerec.GreenScreenFilter;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.KeyEvent;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;
import org.lwjgl.glfw.GLFW;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;

/** واجهة CineRec بأسلوب Premiere: Project | Program | Effect Controls | Timeline. تُفتح بزر Z. */
public class CineRecScreen extends Screen {
    private static final int BG = 0xFF1B1B1B, PANEL = 0xFF232323, HEAD = 0xFF2E2E2E, LINE = 0xFF3C3C3C,
        TEXT = 0xFFDADADA, DIM = 0xFF8C8C8C, ACCENT = 0xFF2D8CEB, RED = 0xFFE5484D, OK = 0xFF2ECC71;
    private static final String[] TABS = {"Recording", "Editing", "Green Screen", "Audio"};
    private static final String[] MIC = {"Phone mic", "Wired headset", "Bluetooth"};
    private static final String[] MOBS = {"minecraft:creeper", "minecraft:zombie", "minecraft:skeleton",
        "minecraft:enderman", "minecraft:villager", "minecraft:pig"};

    private record Hit(int x, int y, int w, int h, Runnable action) {}
    private record Clip(String name, int frames) {}

    private final List<Hit> hits = new ArrayList<>();
    private final List<Clip> clips = new ArrayList<>();
    private int tab, selected = -1, mx, my;
    private double playhead;
    private String tip, stickyTip, status = "";
    private long stickyUntil;

    public CineRecScreen() { super(Component.literal("CineRec")); }

    @Override
    protected void init() { loadClips(); }

    // ------------------------------------------------------------ input

    @Override
    public boolean keyPressed(KeyEvent event) {
        if (event.key() == GLFW.GLFW_KEY_Z || event.key() == GLFW.GLFW_KEY_ESCAPE) {
            onClose();
            return true;
        }
        return super.keyPressed(event);
    }

    @Override
    public boolean mouseClicked(MouseButtonEvent event, boolean doubleClick) {
        mx = (int) event.x();
        my = (int) event.y();
        if (event.button() == 0) {
            for (int i = hits.size() - 1; i >= 0; i--) { // الأخير مرسوم فوق
                Hit h = hits.get(i);
                if (mx >= h.x && mx < h.x + h.w && my >= h.y && my < h.y + h.h) {
                    h.action.run();
                    return true;
                }
            }
        }
        return super.mouseClicked(event, doubleClick);
    }

    // ------------------------------------------------------------ render

    @Override
    public void extractRenderState(GuiGraphicsExtractor g, int mouseX, int mouseY, float partialTick) {
        mx = mouseX; my = mouseY;
        hits.clear();
        tip = null;
        CineRecConfig cfg = CineRecConfig.get();

        rect(g, 0, 0, width, height, BG);
        topBar(g);

        int top = 26, tlH = Math.max(96, height * 36 / 100), bodyH = height - top - tlH;
        int lw = width * 22 / 100, rw = Math.max(140, width * 34 / 100), cw = width - lw - rw;

        panel(g, 0, top, lw, bodyH, "Project");
        projectPanel(g, 0, top, lw);
        panel(g, lw, top, cw, bodyH, "Program");
        monitor(g, lw, top, cw, bodyH);
        panel(g, lw + cw, top, rw, bodyH, "Effect Controls");
        controls(g, cfg, lw + cw, top, rw, bodyH);
        timeline(g, cfg, 0, top + bodyH, width, tlH);
    }

    private void topBar(GuiGraphicsExtractor g) {
        rect(g, 0, 0, width, 26, HEAD);
        txt(g, "CineRec", 8, 9, ACCENT);
        int tx = 12 + font.width("CineRec") + 10;
        for (int i = 0; i < TABS.length; i++) {
            int tw = font.width(TABS[i]) + 14;
            boolean on = i == tab;
            rect(g, tx, 4, tw, 20, on ? PANEL : HEAD);
            if (on) rect(g, tx, 22, tw, 2, ACCENT);
            txt(g, TABS[i], tx + 7, 10, on ? TEXT : DIM);
            final int idx = i;
            hit(tx, 4, tw, 20, () -> tab = idx);
            tx += tw + 2;
        }
        boolean rec = CineRecClient.RECORDER.isRecording();
        String label = rec ? "STOP " + CineRecClient.RECORDER.frames() : "REC";
        int bw = font.width(label) + 26, bx = width - bw - 6;
        rect(g, bx, 4, bw, 18, rec ? RED : 0xFF444444);
        rect(g, bx + 6, 9, 8, 8, rec ? 0xFFFFFFFF : RED);
        txt(g, label, bx + 18, 9, 0xFFFFFFFF);
        hit(bx, 4, bw, 18, this::toggleRec);
    }

    private void projectPanel(GuiGraphicsExtractor g, int x, int top, int w) {
        int y = top + 18;
        if (clips.isEmpty()) {
            txt(g, "No recordings yet", x + 6, y, DIM);
            txt(g, "Press REC", x + 6, y + 12, DIM);
            return;
        }
        for (int i = 0; i < clips.size() && y < height * 64 / 100; i++) {
            Clip c = clips.get(i);
            boolean sel = i == selected;
            rect(g, x + 2, y - 2, w - 4, 14, sel ? ACCENT : (inside(x + 2, y - 2, w - 4, 14) ? 0xFF2F2F2F : PANEL));
            txt(g, trim(c.name, w - 10), x + 6, y + 1, TEXT);
            final int idx = i;
            hit(x + 2, y - 2, w - 4, 14, () -> selected = idx);
            y += 15;
        }
    }

    private void monitor(GuiGraphicsExtractor g, int x, int top, int w, int h) {
        CineRecConfig cfg = CineRecConfig.get();
        int availW = w - 12, availH = h - 14 - 26;
        int bw = Math.max(40, Math.min(availW, availH * 16 / 9)), bh = bw * 9 / 16;
        int bx = x + (w - bw) / 2, by = top + 18;
        rect(g, bx, by, bw, bh, cfg.greenScreen ? 0xFF000000 | cfg.greenColor : 0xFF000000);
        String l1 = cfg.greenScreen ? "GREEN SCREEN" : "WORLD ONLY";
        String l2 = cfg.greenScreen ? "target: " + targetLabel(cfg) : "no HUD, no buttons";
        txt(g, l1, bx + (bw - font.width(l1)) / 2, by + bh / 2 - 9, 0xFFFFFFFF);
        txt(g, l2, bx + (bw - font.width(l2)) / 2, by + bh / 2 + 3, 0xFFDDDDDD);
        int y = by + bh + 6;
        txt(g, time(playhead) + " / " + time(totalSeconds(cfg)), x + 8, y, DIM);
        if (!status.isEmpty()) txt(g, status, x + w - 8 - font.width(status), y, DIM);
    }

    private void controls(GuiGraphicsExtractor g, CineRecConfig cfg, int x0, int top, int w, int h) {
        int x = x0 + 6, cw = w - 12, y = top + 20;
        switch (tab) {
            case 0 -> {
                y = toggle(g, x, y, cw, "Hide name tags", "hideNames", cfg.hideNames,
                    () -> cfg.hideNames = !cfg.hideNames);
                y = stepper(g, x, y, cw, "FPS", "fps", cfg.fps,
                    () -> cfg.fps = Math.max(6, cfg.fps - 6), () -> cfg.fps = Math.min(60, cfg.fps + 6));
                txt(g, "World only - no HUD/buttons", x + 2, y + 2, DIM);
                boolean ok = GreenScreenFilter.nameHookCalls > 0;
                txt(g, ok ? "Name hook: active" : "Name hook: no calls yet", x + 2, y + 14, ok ? OK : DIM);
            }
            case 1 -> {
                Clip c = selected >= 0 && selected < clips.size() ? clips.get(selected) : null;
                txt(g, c == null ? "Select a clip in Project" : trim(c.name, cw), x + 2, y, TEXT);
                txt(g, "Click the timeline = playhead", x + 2, y + 12, DIM);
                y += 28;
                int bw = (cw - 8) / 3;
                button(g, x, y, bw, "Set In", () -> setTrim(true));
                button(g, x + bw + 4, y, bw, "Set Out", () -> setTrim(false));
                button(g, x + 2 * (bw + 4), y, bw, "Reset", this::resetTrim);
                if (inside(x, y, cw, 18)) tip = "trim";
                y += 24;
                txt(g, "Export: next phase", x + 2, y, DIM);
            }
            case 2 -> {
                y = toggle(g, x, y, cw, "Green screen", "greenScreen", cfg.greenScreen,
                    () -> cfg.greenScreen = !cfg.greenScreen);
                y = cycle(g, x, y, cw, "Target", "greenScreen", targetLabel(cfg), () -> nextTarget(cfg));
                boolean ok = GreenScreenFilter.hookCalls > 0;
                txt(g, ok ? "Filter hook: active" : "Filter hook: no calls yet", x + 2, y + 2, ok ? OK : DIM);
            }
            default -> {
                y = cycle(g, x, y, cw, "Mic", "audio", MIC[Math.floorMod(cfg.micSource, 3)], () -> {
                    cfg.micSource = (cfg.micSource + 1) % 3;
                });
                txt(g, "Audio capture: next phase", x + 2, y + 2, DIM);
            }
        }
        String show = tip != null ? tip : (System.currentTimeMillis() < stickyUntil ? stickyTip : null);
        if (show == null) show = switch (tab) { case 0 -> "fps"; case 1 -> "trim"; case 2 -> "greenScreen"; default -> "audio"; };
        int ah = ScratchArt.height(show);
        ScratchArt.draw(g, font, show, x, top + h - ah - 6, cw);
    }

    private void timeline(GuiGraphicsExtractor g, CineRecConfig cfg, int x, int y, int w, int h) {
        panel(g, x, y, w, h, "Timeline");
        int x0 = x + 50, x1 = x + w - 8;
        int rulerY = y + 16, v2 = rulerY + 16, v1 = v2 + 22, a1 = v1 + 22;
        double total = Math.max(10, totalSeconds(cfg));
        double pps = (x1 - x0) / total;

        // ruler
        int step = total > 60 ? 10 : total > 20 ? 5 : 1;
        for (int t = 0; t <= total; t += step) {
            int tx = x0 + (int) (t * pps);
            rect(g, tx, rulerY + 8, 1, 5, DIM);
            if (t % Math.max(step, 5) == 0) txt(g, t + "s", tx + 2, rulerY, DIM);
        }
        txt(g, "V2", x + 6, v2 + 5, DIM);
        txt(g, "V1", x + 6, v1 + 5, DIM);
        txt(g, "A1", x + 6, a1 + 5, DIM);
        rect(g, x0, v2, x1 - x0, 18, 0xFF1F1F1F);
        rect(g, x0, v1, x1 - x0, 18, 0xFF1F1F1F);
        rect(g, x0, a1, x1 - x0, 18, 0xFF1F1F1F);

        // النقر على الريزر/التراكات يحرك الـ playhead
        hit(x0, rulerY, x1 - x0, a1 + 18 - rulerY, () -> {
            playhead = Math.max(0, Math.min(total, (mx - x0) / pps));
        });

        // V1: الكليبات
        double t = 0;
        for (int i = 0; i < clips.size(); i++) {
            Clip c = clips.get(i);
            double dur = secs(c, cfg);
            int cx = x0 + (int) (t * pps), cwid = Math.max(4, (int) (dur * pps));
            rect(g, cx, v1, cwid, 18, i == selected ? ACCENT : 0xFF4B6FA5);
            txt(g, trim(c.name, cwid - 4), cx + 3, v1 + 5, 0xFFFFFFFF);
            double[] tr = cfg.trims.get(c.name);
            if (tr != null) {
                rect(g, cx + (int) (tr[0] * pps), v1, 2, 18, 0xFFFFD43B);
                rect(g, cx + (int) (tr[1] * pps), v1, 2, 18, 0xFFFFD43B);
            }
            final int idx = i;
            hit(cx, v1, cwid, 18, () -> {
                selected = idx;
                playhead = Math.max(0, Math.min(total, (mx - x0) / pps));
            });
            t += dur;
        }
        if (clips.isEmpty()) txt(g, "Record something to see clips here", x0 + 6, v1 + 5, DIM);
        int endX = x0 + (int) (Math.max(t, 0.5) * pps);

        // V2: الجرين سكرين
        if (cfg.greenScreen && !clips.isEmpty()) {
            rect(g, x0, v2, endX - x0, 18, 0xFF1E8449);
            txt(g, "Green: " + targetLabel(cfg), x0 + 4, v2 + 5, 0xFFFFFFFF);
        }
        // A1: الصوت (شكل موجة تجريبي)
        if (!clips.isEmpty()) {
            rect(g, x0, a1, endX - x0, 18, 0xFF2E5E48);
            for (int px = x0 + 2; px < endX - 2; px += 3) {
                int wh = 3 + (int) (Math.abs(Math.sin(px * 0.35)) * 9);
                rect(g, px, a1 + 9 - wh / 2, 2, wh, 0xFF7BE0A8);
            }
            txt(g, MIC[Math.floorMod(cfg.micSource, 3)], x0 + 4, a1 + 5, 0xFFFFFFFF);
        }
        // playhead
        int px = x0 + (int) (playhead * pps);
        rect(g, px, rulerY, 1, a1 + 18 - rulerY, RED);
        rect(g, px - 3, rulerY, 7, 4, RED);
    }

    // ------------------------------------------------------------ widgets

    private int toggle(GuiGraphicsExtractor g, int x, int y, int w, String label, String tipId,
                       boolean value, Runnable flip) {
        boolean hov = inside(x, y, w, 20);
        rect(g, x, y, w, 20, hov ? 0xFF2C2C2C : PANEL);
        txt(g, label, x + 6, y + 6, TEXT);
        int pw = 26, ph = 12, px = x + w - pw - 6, py = y + 4;
        rect(g, px, py, pw, ph, value ? ACCENT : 0xFF555555);
        rect(g, value ? px + pw - ph + 1 : px + 1, py + 1, ph - 2, ph - 2, 0xFFFFFFFF);
        hit(x, y, w, 20, () -> { flip.run(); afterChange(tipId); });
        if (hov) tip = tipId;
        return y + 22;
    }

    private int stepper(GuiGraphicsExtractor g, int x, int y, int w, String label, String tipId,
                        int value, Runnable minus, Runnable plus) {
        boolean hov = inside(x, y, w, 20);
        rect(g, x, y, w, 20, hov ? 0xFF2C2C2C : PANEL);
        txt(g, label, x + 6, y + 6, TEXT);
        int bx = x + w - 72;
        rect(g, bx, y + 3, 14, 14, 0xFF444444);
        txt(g, "-", bx + 5, y + 6, TEXT);
        String v = String.valueOf(value);
        txt(g, v, bx + 14 + (28 - font.width(v)) / 2, y + 6, TEXT);
        rect(g, bx + 42, y + 3, 14, 14, 0xFF444444);
        txt(g, "+", bx + 46, y + 6, TEXT);
        hit(bx, y + 3, 14, 14, () -> { minus.run(); afterChange(tipId); });
        hit(bx + 42, y + 3, 14, 14, () -> { plus.run(); afterChange(tipId); });
        if (hov) tip = tipId;
        return y + 22;
    }

    private int cycle(GuiGraphicsExtractor g, int x, int y, int w, String label, String tipId,
                      String value, Runnable next) {
        boolean hov = inside(x, y, w, 20);
        rect(g, x, y, w, 20, hov ? 0xFF2C2C2C : PANEL);
        txt(g, label, x + 6, y + 6, TEXT);
        String v = trim(value, w - 50);
        int vw = font.width(v) + 10;
        rect(g, x + w - vw - 4, y + 3, vw, 14, 0xFF3A3A3A);
        txt(g, v, x + w - vw + 1, y + 6, ACCENT);
        hit(x, y, w, 20, () -> { next.run(); afterChange(tipId); });
        if (hov) tip = tipId;
        return y + 22;
    }

    private void button(GuiGraphicsExtractor g, int x, int y, int w, String label, Runnable a) {
        rect(g, x, y, w, 18, inside(x, y, w, 18) ? ACCENT : 0xFF3A3A3A);
        txt(g, label, x + (w - font.width(label)) / 2, y + 5, TEXT);
        hit(x, y, w, 18, a);
    }

    private void panel(GuiGraphicsExtractor g, int x, int y, int w, int h, String title) {
        rect(g, x, y, w, h, PANEL);
        rect(g, x, y, w, 14, HEAD);
        txt(g, title, x + 6, y + 3, DIM);
        rect(g, x + w - 1, y, 1, h, LINE);
        rect(g, x, y + h - 1, w, 1, LINE);
    }

    private void afterChange(String tipId) {
        CineRecConfig.get().save();
        stickyTip = tipId;
        stickyUntil = System.currentTimeMillis() + 4000;
    }

    // ------------------------------------------------------------ logic

    private void toggleRec() {
        var r = CineRecClient.RECORDER;
        if (r.isRecording()) {
            int n = r.stop();
            status = "Saved " + n + " frames";
            loadClips();
        } else {
            try {
                r.start();
                status = "Recording... (close menu with Z)";
            } catch (IOException e) {
                status = "Error: " + e.getMessage();
            }
        }
    }

    private void setTrim(boolean in) {
        if (selected < 0 || selected >= clips.size()) return;
        CineRecConfig cfg = CineRecConfig.get();
        Clip c = clips.get(selected);
        double dur = secs(c, cfg), rel = Math.max(0, Math.min(dur, playhead - clipStart(selected, cfg)));
        double[] t = cfg.trims.computeIfAbsent(c.name, k -> new double[]{0, dur});
        t[in ? 0 : 1] = rel;
        cfg.save();
    }

    private void resetTrim() {
        if (selected < 0 || selected >= clips.size()) return;
        CineRecConfig cfg = CineRecConfig.get();
        cfg.trims.remove(clips.get(selected).name);
        cfg.save();
    }

    private void nextTarget(CineRecConfig cfg) {
        List<String> list = new ArrayList<>();
        list.add("self");
        if (minecraft != null && minecraft.level != null) {
            for (var p : minecraft.level.players()) list.add("player:" + p.getName().getString());
        }
        for (String m : MOBS) list.add("mob:" + m);
        String cur = cfg.targetMode.equals("self") ? "self" : cfg.targetMode + ":" + cfg.targetValue;
        int i = (list.indexOf(cur) + 1) % list.size();
        String n = list.get(i);
        int c = n.indexOf(':');
        cfg.targetMode = c < 0 ? n : n.substring(0, c);
        cfg.targetValue = c < 0 ? "" : n.substring(c + 1);
    }

    private String targetLabel(CineRecConfig cfg) {
        return switch (cfg.targetMode) {
            case "player" -> cfg.targetValue;
            case "mob" -> cfg.targetValue.replace("minecraft:", "");
            default -> "me";
        };
    }

    private void loadClips() {
        clips.clear();
        Path root = FabricLoader.getInstance().getGameDir().resolve("cinerec");
        if (!Files.isDirectory(root)) return;
        try (Stream<Path> dirs = Files.list(root)) {
            dirs.filter(Files::isDirectory).sorted().forEach(d ->
                clips.add(new Clip(d.getFileName().toString(), countFrames(d))));
        } catch (IOException ignored) {
        }
    }

    private static int countFrames(Path dir) {
        try (Stream<Path> f = Files.list(dir)) {
            return (int) f.filter(p -> p.toString().endsWith(".png")).count();
        } catch (IOException e) {
            return 0;
        }
    }

    private double secs(Clip c, CineRecConfig cfg) { return c.frames / (double) Math.max(1, cfg.fps); }

    private double clipStart(int idx, CineRecConfig cfg) {
        double t = 0;
        for (int i = 0; i < idx; i++) t += secs(clips.get(i), cfg);
        return t;
    }

    private double totalSeconds(CineRecConfig cfg) { return clipStart(clips.size(), cfg); }

    // ------------------------------------------------------------ helpers

    private void rect(GuiGraphicsExtractor g, int x, int y, int w, int h, int color) { g.fill(x, y, x + w, y + h, color); }

    private void txt(GuiGraphicsExtractor g, String s, int x, int y, int color) { g.text(font, s, x, y, color); }

    private void hit(int x, int y, int w, int h, Runnable a) { hits.add(new Hit(x, y, w, h, a)); }

    private boolean inside(int x, int y, int w, int h) { return mx >= x && mx < x + w && my >= y && my < y + h; }

    private String trim(String s, int maxPx) {
        if (font.width(s) <= maxPx) return s;
        while (s.length() > 1 && font.width(s + "..") > maxPx) s = s.substring(0, s.length() - 1);
        return s + "..";
    }

    private static String time(double s) { return String.format("%02d:%04.1f", (int) (s / 60), s % 60); }
}
