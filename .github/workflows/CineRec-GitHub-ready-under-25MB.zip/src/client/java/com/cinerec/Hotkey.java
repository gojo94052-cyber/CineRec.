package com.cinerec;

import com.cinerec.ui.CineRecScreen;
import net.minecraft.client.Minecraft;
import org.lwjgl.glfw.GLFW;

public final class Hotkey {
    private static boolean wasDown;

    private Hotkey() {}

    /** يُستدعى كل إطار من MinecraftMixin. */
    public static void poll(Minecraft mc) {
        if (mc.player == null) { wasDown = false; return; }
        boolean down = GLFW.glfwGetKey(mc.getWindow().handle(), GLFW.GLFW_KEY_Z) == GLFW.GLFW_PRESS;
        if (down && !wasDown && mc.gui.screen() == null) {
            mc.gui.setScreen(new CineRecScreen());
        }
        wasDown = down;
    }
}
