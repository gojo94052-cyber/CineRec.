package com.cinerec;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.Map;

/** الإعدادات + مشروع المونتاج (trim)، تنحفظ في config/cinerec.json */
public final class CineRecConfig {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("cinerec.json");
    private static CineRecConfig instance;

    public int fps = 30;
    public boolean hideNames = false;

    public boolean greenScreen = false;
    /** self / player / mob */
    public String targetMode = "self";
    public String targetValue = "";
    public int greenColor = 0x00B140;

    /** 0 = Phone mic, 1 = Wired headset, 2 = Bluetooth (التسجيل نفسه في مرحلة لاحقة) */
    public int micSource = 0;

    /** اسم الجلسة -> [بداية, نهاية] بالثواني داخل الكليب */
    public Map<String, double[]> trims = new HashMap<>();

    public static synchronized CineRecConfig get() {
        if (instance == null) {
            try {
                instance = Files.exists(FILE)
                    ? GSON.fromJson(Files.readString(FILE), CineRecConfig.class)
                    : new CineRecConfig();
            } catch (Exception e) {
                instance = new CineRecConfig();
            }
            if (instance == null) instance = new CineRecConfig();
            if (instance.trims == null) instance.trims = new HashMap<>();
        }
        return instance;
    }

    public void save() {
        try {
            Files.createDirectories(FILE.getParent());
            Files.writeString(FILE, GSON.toJson(this));
        } catch (IOException ignored) {
        }
    }
}
