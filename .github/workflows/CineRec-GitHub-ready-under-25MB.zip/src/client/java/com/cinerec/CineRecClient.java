package com.cinerec;

import net.fabricmc.api.ClientModInitializer;

public class CineRecClient implements ClientModInitializer {
    public static final FrameRecorder RECORDER = new FrameRecorder();

    @Override
    public void onInitializeClient() {
        CineRecConfig.get(); // تحميل الإعدادات. كل شي ثاني (زر Z، اللقط) يجي من الـ Mixins.
    }
}
